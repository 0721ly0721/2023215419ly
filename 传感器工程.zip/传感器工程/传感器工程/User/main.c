#include "stm32f10x.h"
#include "Delay.h"
#include "LED.h"
#include "DHT11.h"
#include "Serial.h"
#include "PWM.h"
#include "Key.h"

DHT11_Data_TypeDef DHT11_Data;		//传感器温度值
uint8_t t=25;			//温度阈值
uint8_t keynum;
uint16_t i;

int main(void)
{
	LED_Init();
	DHT11_GPIO_Config();
	Serial_Init();		
	PWM_Init();			
	Key_Init();
	
	
	LED1_ON();
	Delay_ms(50);
	LED1_OFF();
	Delay_ms(50);
	
	LED1_ON();
	Delay_ms(50);
	LED1_OFF();
	Delay_ms(50);
	
	LED1_ON();
	
	
	while (1)
	{
		
		keynum=Key_GetNum();
		if(keynum ==1)
		{
			t=t+5;
			if(t>35){t=25;}
		}
		//按键操作
		
		if(Read_DHT11(&DHT11_Data) == SUCCESS)
		{
			
			if(DHT11_Data.temp_int>=t)
			{  
				LED1_OFF();
				
				for (i = 0; i <= 1000; i++)
		      {
			PWM_SetCompare1(i);			//依次将定时器的CCR寄存器设置为0~1000，PWM占空比逐渐增大，LED逐渐变亮
			Delay_ms(2);				//延时2ms
		      }	
			}
			else
			{
			   LED1_ON();
				GPIO_ResetBits(GPIOA, GPIO_Pin_0);
			}
			//指示灯变换
		   
			Serial_Printf("Tem:%d.%d\r\n",DHT11_Data.temp_int,DHT11_Data.temp_deci);
			
			if(Serial_RxFlag == 1)		//如果接收到数据包
		  {
			/*将收到的数据包与预设的指令对比，以此决定将要执行的操作*/
			if (strcmp(Serial_RxPacket, "19") == 0)			//如果收到指令
			{
				Serial_Printf("t=%d",t);
				Serial_SendString("\r\n");				
			}

			else						//上述所有条件均不满足，即收到了未知指令
			{
				Serial_SendString("invalid instruction\r\n");			//串口回传一个字符串	
			}
			
			Serial_RxFlag = 0;			//处理完成后，需要将接收数据包标志位清零，否则将无法接收后续数据包
		  }
		  
		  Delay_ms(200);
		  
		}		
	}
}


